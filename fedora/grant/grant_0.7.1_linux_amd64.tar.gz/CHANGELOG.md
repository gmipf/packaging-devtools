### Dependencies

9 dependency changes (9 updated). 3 vulnerabilities remediated.

**🟢 Remediated (3)**

- [GO-2026-6860](https://go.dev/cl/849365) (High) — golang.org/x/net
- [GO-2026-6866](https://go.dev/cl/855121) (Medium) — golang.org/x/net
- [GO-2026-6888](https://github.com/andybalholm/brotli/security/advisories/GHSA-c9gr-gmg4-2vqv) (Critical) — github.com/andybalholm/brotli

<details>
<summary>Updated (9 packages)</summary>

- github.com/anchore/stereoscope `v0.4.0` → `v0.4.1`
- github.com/anchore/syft `v1.56.0` → `v1.57.1`
- github.com/andybalholm/brotli `v1.2.0` → `v1.2.8` **(🟢 remediated [GO-2026-6888](https://github.com/andybalholm/brotli/security/advisories/GHSA-c9gr-gmg4-2vqv))**
- github.com/bmatcuk/doublestar/v4 `v4.10.3` → `v4.10.4`
- github.com/gkampitakis/go-snaps `v0.5.24` → `v0.5.25`
- github.com/gpustack/gguf-parser-go `v0.27.0` → `v0.28.1`
- github.com/moby/sys/mountinfo `v0.7.2` → `v0.7.3`
- go.yaml.in/yaml/v3 `v3.0.5` → `v3.0.6`
- golang.org/x/net `v0.61.0` → `v0.62.0` **(🟢 remediated [GO-2026-6860](https://go.dev/cl/849365), [GO-2026-6866](https://go.dev/cl/855121))**
</details>

**[(Full Changelog)](https://github.com/anchore/grant/compare/v0.7.0...v0.7.1)**
