### Added Features

- Support SPDX "user defined license reference" (aka LicenseRef) [Issue [#157](https://github.com/anchore/grant/issues/157)] [PR [#601](https://github.com/anchore/grant/pull/601) @wagoodman]
- Windows binary builds of grant / Windows as a supported platform [Issue [#154](https://github.com/anchore/grant/issues/154)] [PR [#440](https://github.com/anchore/grant/pull/440) @waqas-ashraf-venturedive]

### Bug Fixes

- update mergeDuplicatePackages call sites to new signature [PR [#628](https://github.com/anchore/grant/pull/628) @willmurphyscode]
- windows-safe config discovery and OS-independent policy globs [PR [#599](https://github.com/anchore/grant/pull/599) @wagoodman]
- use the license classifier directly instead of its tools backend [PR [#598](https://github.com/anchore/grant/pull/598) @wagoodman]
- sign release checksums with a sigstore bundle [PR [#594](https://github.com/anchore/grant/pull/594) @wagoodman]
- distinguish java packages sharing an artifact id [PR [#571](https://github.com/anchore/grant/pull/571) @spiffcs]
- guard against panic on malformed SPDX license expression [PR [#548](https://github.com/anchore/grant/pull/548) @arpitjain099]
- bug: Grant fails to scan a RHEL9 container containing the 'kernel-headers' package [Issue [#122](https://github.com/anchore/grant/issues/122)] [PR [#601](https://github.com/anchore/grant/pull/601) @wagoodman]
- Follow/resolve directory symlinks during license file search [Issue [#401](https://github.com/anchore/grant/issues/401)] [PR [#554](https://github.com/anchore/grant/pull/554) @Eljees]
- bug: output can span many lines, making it difficult to read [Issue [#276](https://github.com/anchore/grant/issues/276)] [PR [#556](https://github.com/anchore/grant/pull/556) @Eljees]

### Additional Changes

- Multiple license assigned ( WITH / OR ) operator [Issue [#500](https://github.com/anchore/grant/issues/500)] [PR [#555](https://github.com/anchore/grant/pull/555) @Eljees]
- Count each package once in grant list [PR [#610](https://github.com/anchore/grant/pull/610) @arpitjain099]
- move images to distroless static-debian13 [PR [#618](https://github.com/anchore/grant/pull/618) @wagoodman]
- bump go-make module and action together [PR [#607](https://github.com/anchore/grant/pull/607) @wagoodman]
- add COPYRIGHT and CONTRIBUTORS.md files [PR [#606](https://github.com/anchore/grant/pull/606) @wagoodman]
- fail the unit test gate when any platform fails [PR [#600](https://github.com/anchore/grant/pull/600) @wagoodman]
- Preserve quoted paths when running tagged installer scripts [PR [#595](https://github.com/anchore/grant/pull/595) @wagoodman]

### Dependencies

176 dependency changes (138 updated, 32 added, 6 removed). 29 vulnerabilities remediated.

**🟢 Remediated (29)**

- [GHSA-259r-337f-4rfw](https://github.com/advisories/GHSA-259r-337f-4rfw) (High) — github.com/klauspost/compress
- [GHSA-2v4p-qf9q-27wj](https://github.com/advisories/GHSA-2v4p-qf9q-27wj) (High) — google.golang.org/grpc
- [GHSA-4w3g-jfj2-cw2q](https://github.com/advisories/GHSA-4w3g-jfj2-cw2q) (Medium) — github.com/go-jose/go-jose/v4
- [GHSA-7jxh-36q5-gcqv](https://github.com/advisories/GHSA-7jxh-36q5-gcqv) (Medium) — github.com/containerd/containerd/v2
- [GHSA-8wmf-6v46-5gfg](https://github.com/advisories/GHSA-8wmf-6v46-5gfg) (Low) — go.opentelemetry.io/otel/sdk
- [GHSA-hc8v-wwc9-vgxm](https://github.com/advisories/GHSA-hc8v-wwc9-vgxm) (High) — github.com/go-git/go-git/v5
- [GHSA-hrxh-6v49-42gf](https://github.com/advisories/GHSA-hrxh-6v49-42gf) (High) — google.golang.org/grpc
- [GHSA-mgcc-cww5-fp2q](https://github.com/advisories/GHSA-mgcc-cww5-fp2q) (High) — github.com/go-jose/go-jose/v4
- [GHSA-mjcv-p78q-w5fw](https://github.com/advisories/GHSA-mjcv-p78q-w5fw) (Medium) — github.com/moby/sys/user
- [GHSA-p7v4-vr35-mj6f](https://github.com/advisories/GHSA-p7v4-vr35-mj6f) (High) — github.com/containerd/containerd/v2
- [GHSA-pg57-6jwg-q645](https://github.com/advisories/GHSA-pg57-6jwg-q645) (Medium) — github.com/containerd/containerd/v2
- [GHSA-qc2q-p7wx-3px3](https://github.com/advisories/GHSA-qc2q-p7wx-3px3) (Medium) — google.golang.org/grpc
- [GHSA-qgq7-7hm3-q39j](https://github.com/advisories/GHSA-qgq7-7hm3-q39j) (Medium) — github.com/go-git/go-git/v5
- [GHSA-rp3h-jf77-q9p4](https://github.com/advisories/GHSA-rp3h-jf77-q9p4) (Medium) — github.com/containerd/containerd/v2
- [GHSA-vp52-pcj8-j9qc](https://github.com/advisories/GHSA-vp52-pcj8-j9qc) (High) — google.golang.org/grpc
- [GHSA-vvm8-gf78-28g4](https://github.com/advisories/GHSA-vvm8-gf78-28g4) (Medium) — github.com/go-jose/go-jose/v4
- [GO-2026-5158](https://github.com/open-telemetry/opentelemetry-go/security/advisories/GHSA-5wrp-cwcj-q835) (Medium) — go.opentelemetry.io/otel
- [GO-2026-5970](https://go.dev/issue/80142) (High) — golang.org/x/text
- [GO-2026-6179](https://go.dev/issue/80744) (High) — golang.org/x/mod
- [GO-2026-6180](https://go.dev/issue/80745) (High) — golang.org/x/mod
- [GO-2026-6303](https://go.dev/issue/80213) (High) — golang.org/x/crypto
- [GO-2026-6354](https://go.dev/issue/81316) (High) — golang.org/x/crypto
- [GO-2026-6355](https://go.dev/issue/81317) (High) — golang.org/x/crypto
- [GO-2026-6603](https://go.dev/cl/847185) (High) — golang.org/x/net
- [GO-2026-6610](https://go.dev/cl/835145) (High) — golang.org/x/net
- [GO-2026-6611](https://go.dev/cl/847186) (High) — golang.org/x/net
- [GO-2026-6612](https://go.dev/cl/847187) (Critical) — golang.org/x/net
- [GO-2026-6617](https://go.dev/cl/847188) (High) — golang.org/x/net
- [GO-2026-6629](https://go.dev/cl/793360) (High) — golang.org/x/text

**Toolchains (1)**

- Go minimum version: `1.26.3` → `1.26.8`

<details>
<summary>Updated (138 packages)</summary>

- cel.dev/expr `v0.25.1` → `v0.25.2`
- cloud.google.com/go/auth `v0.18.2` → `v0.23.3`
- cloud.google.com/go/compute/metadata `v0.9.0` → `v0.9.1`
- cloud.google.com/go/iam `v1.5.3` → `v1.12.0`
- cloud.google.com/go/logging `v1.13.1` → `v1.19.0`
- cloud.google.com/go/longrunning `v0.8.0` → `v1.2.0`
- cloud.google.com/go/monitoring `v1.24.3` → `v1.30.0`
- cloud.google.com/go/storage `v1.61.3` → `v1.68.0`
- cloud.google.com/go/trace `v1.11.7` → `v1.16.0`
- github.com/CycloneDX/cyclonedx-go `v0.11.0` → `v0.12.0`
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/detectors/gcp `v1.31.0` → `v1.34.0`
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/exporter/metric `v0.55.0` → `v0.57.0`
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/internal/cloudmock `v0.55.0` → `v0.57.0`
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/internal/resourcemapping `v0.55.0` → `v0.57.0`
- github.com/Microsoft/go-winio `v0.6.3-0.ad3df93` → `v0.6.3-0.f19d971`
- github.com/Microsoft/hcsshim `v0.15.0-rc.1` → `v0.15.0-rc.4`
- github.com/ProtonMail/go-crypto `v1.4.1` → `v1.5.2`
- github.com/anchore/clio `v0.1.1` → `v0.1.2`
- github.com/anchore/go-logger `v0.1.1` → `v0.2.0`
- github.com/anchore/go-rpmdb `v0.1.0` → `v0.2.2`
- github.com/anchore/go-sync `v0.1.1` → `v0.1.2`
- github.com/anchore/stereoscope `v0.2.2` → `v0.4.0`
- github.com/anchore/syft `v1.46.0` → `v1.56.0`
- github.com/aws/aws-sdk-go-v2 `v1.41.5` → `v1.47.1`
- github.com/aws/aws-sdk-go-v2/aws/protocol/eventstream `v1.7.8` → `v1.7.20`
- github.com/aws/aws-sdk-go-v2/config `v1.32.12` → `v1.33.6`
- github.com/aws/aws-sdk-go-v2/credentials `v1.19.12` → `v1.20.6`
- github.com/aws/aws-sdk-go-v2/feature/ec2/imds `v1.18.20` → `v1.20.1`
- github.com/aws/aws-sdk-go-v2/internal/configsources `v1.4.21` → `v1.5.4`
- github.com/aws/aws-sdk-go-v2/internal/endpoints/v2 `v2.7.21` → `v2.8.4`
- github.com/aws/aws-sdk-go-v2/internal/v4a `v1.4.22` → `v1.5.4`
- github.com/aws/aws-sdk-go-v2/service/internal/accept-encoding `v1.13.7` → `v1.13.19`
- github.com/aws/aws-sdk-go-v2/service/internal/checksum `v1.9.13` → `v1.11.5`
- github.com/aws/aws-sdk-go-v2/service/internal/presigned-url `v1.13.21` → `v1.14.4`
- github.com/aws/aws-sdk-go-v2/service/internal/s3shared `v1.19.21` → `v1.20.4`
- github.com/aws/aws-sdk-go-v2/service/s3 `v1.97.3` → `v1.114.0`
- github.com/aws/aws-sdk-go-v2/service/signin `v1.0.8` → `v1.10.1`
- github.com/aws/aws-sdk-go-v2/service/sso `v1.30.13` → `v1.38.1`
- github.com/aws/aws-sdk-go-v2/service/ssooidc `v1.35.17` → `v1.43.1`
- github.com/aws/aws-sdk-go-v2/service/sts `v1.41.9` → `v1.51.1`
- github.com/aws/smithy-go `v1.24.2` → `v1.28.1`
- github.com/bmatcuk/doublestar/v4 `v4.10.0` → `v4.10.3`
- github.com/cncf/xds/go `v0.0.0-ee656c7` → `v0.0.0-dba9d58`
- github.com/containerd/containerd/api `v1.11.1` → `v1.12.0`
- github.com/containerd/containerd/v2 `v2.3.2` → `v2.4.2` **(🟢 remediated [GHSA-7jxh-36q5-gcqv](https://github.com/advisories/GHSA-7jxh-36q5-gcqv), [GHSA-p7v4-vr35-mj6f](https://github.com/advisories/GHSA-p7v4-vr35-mj6f), [GHSA-pg57-6jwg-q645](https://github.com/advisories/GHSA-pg57-6jwg-q645), [GHSA-rp3h-jf77-q9p4](https://github.com/advisories/GHSA-rp3h-jf77-q9p4))**
- github.com/containerd/log `v0.1.0` → `v0.2.0`
- github.com/containerd/platforms `v1.0.0-rc.4` → `v1.0.0-rc.5`
- github.com/containerd/ttrpc `v1.2.8` → `v1.2.9`
- github.com/containerd/typeurl/v2 `v2.2.3` → `v2.3.0`
- github.com/cyphar/filepath-securejoin `v0.6.1` → `v0.7.0`
- github.com/deitch/magic `v0.0.0-1ff89d7` → `v1.0.0`
- github.com/diskfs/go-diskfs `v1.9.3` → `v1.9.4`
- github.com/docker/cli `v29.5.3+incompatible` → `v29.9.2+incompatible`
- github.com/docker/docker-credential-helpers `v0.9.5` → `v0.9.10`
- github.com/docker/go-connections `v0.7.0` → `v0.8.2`
- github.com/dustin/go-humanize `v1.0.1` → `v1.1.0`
- github.com/envoyproxy/go-control-plane/envoy `v1.36.0` → `v1.37.0`
- github.com/envoyproxy/protoc-gen-validate `v1.3.0` → `v1.3.3`
- github.com/erofs/go-erofs `v0.3.0` → `v0.3.1`
- github.com/fatih/color `v1.18.0` → `v1.19.0`
- github.com/felixge/httpsnoop `v1.0.4` → `v1.1.0`
- github.com/fsnotify/fsnotify `v1.9.0` → `v1.10.1`
- github.com/gabriel-vasile/mimetype `v1.4.13` → `v1.4.16`
- github.com/github/go-spdx/v2 `v2.7.0` → `v2.8.0`
- github.com/gkampitakis/go-snaps `v0.5.22` → `v0.5.24`
- github.com/glebarez/go-sqlite `v1.20.3` → `v1.23.0`
- github.com/go-git/go-billy/v5 `v5.9.0` → `v5.9.2`
- github.com/go-git/go-git/v5 `v5.19.1` → `v5.19.3` **(🟢 remediated [GHSA-hc8v-wwc9-vgxm](https://github.com/advisories/GHSA-hc8v-wwc9-vgxm), [GHSA-qgq7-7hm3-q39j](https://github.com/advisories/GHSA-qgq7-7hm3-q39j))**
- github.com/go-jose/go-jose/v4 `v4.1.4` → `v4.1.6` **(🟢 remediated [GHSA-4w3g-jfj2-cw2q](https://github.com/advisories/GHSA-4w3g-jfj2-cw2q), [GHSA-mgcc-cww5-fp2q](https://github.com/advisories/GHSA-mgcc-cww5-fp2q), [GHSA-vvm8-gf78-28g4](https://github.com/advisories/GHSA-vvm8-gf78-28g4))**
- github.com/go-logr/logr `v1.4.3` → `v1.4.4`
- github.com/go-test/deep `v1.1.1` → `v1.1.2`
- github.com/google/go-containerregistry `v0.21.7` → `v0.22.1`
- github.com/google/pprof `v0.0.0-a4b03ec` → `v0.0.0-1facf8f`
- github.com/google/s2a-go `v0.1.9` → `v0.1.10`
- github.com/googleapis/enterprise-certificate-proxy `v0.3.14` → `v0.3.22`
- github.com/googleapis/gax-go/v2 `v2.17.0` → `v2.24.1`
- github.com/gookit/color `v1.6.1` → `v1.6.3`
- github.com/gpustack/gguf-parser-go `v0.24.1` → `v0.27.0`
- github.com/hashicorp/aws-sdk-go-base/v2 `v2.0.0-beta.72` → `v2.0.0-beta.74`
- github.com/hashicorp/go-getter `v1.8.6` → `v1.8.10`
- github.com/hashicorp/go-version `v1.8.0` → `v1.9.0`
- github.com/hashicorp/hcl/v2 `v2.24.0` → `v2.25.0`
- github.com/jedib0t/go-pretty/v6 `v6.8.1` → `v6.8.3`
- github.com/klauspost/compress `v1.18.6` → `v1.20.3` **(🟢 remediated [GHSA-259r-337f-4rfw](https://github.com/advisories/GHSA-259r-337f-4rfw))**
- github.com/klauspost/pgzip `v1.2.6` → `v1.2.7`
- github.com/magiconair/properties `v1.8.10` → `v1.18.12`
- github.com/mattn/go-isatty `v0.0.20` → `v0.0.24`
- github.com/mattn/go-runewidth `v0.0.21` → `v0.0.31`
- github.com/moby/moby/api `v1.54.2` → `v1.56.1`
- github.com/moby/moby/client `v0.4.1` → `v0.6.2`
- github.com/moby/sys/user `v0.4.0` → `v0.4.1` **(🟢 remediated [GHSA-mjcv-p78q-w5fw](https://github.com/advisories/GHSA-mjcv-p78q-w5fw))**
- github.com/moby/sys/userns `v0.1.0` → `v0.2.1`
- github.com/ncruces/go-strftime `v1.0.0` → `v1.1.0`
- github.com/nwaples/rardecode/v2 `v2.2.0` → `v2.4.1`
- github.com/olekukonko/tablewriter `v1.1.4` → `v1.1.5`
- github.com/pelletier/go-toml/v2 `v2.3.1` → `v2.4.3`
- github.com/pjbgf/sha1cd `v0.6.0` → `v0.7.0`
- github.com/prometheus/procfs `v0.19.2` → `v0.21.1`
- github.com/sirupsen/logrus `v1.9.4` → `v1.10.2`
- github.com/spiffe/go-spiffe/v2 `v2.6.0` → `v2.8.1`
- github.com/stretchr/objx `v0.5.2` → `v0.5.3`
- github.com/stretchr/testify `v1.11.1` → `v1.12.1`
- github.com/sylabs/sif/v2 `v2.24.1` → `v2.24.2`
- github.com/terminalstatic/go-xsd-validate `v0.1.6` → `v0.1.8`
- github.com/ulikunitz/xz `v0.5.15` → `v0.5.17`
- github.com/zclconf/go-cty `v1.16.3` → `v1.19.0`
- go.opentelemetry.io/contrib/detectors/gcp `v1.39.0` → `v1.44.0`
- go.opentelemetry.io/contrib/instrumentation/google.golang.org/grpc/otelgrpc `v0.68.0` → `v0.71.0`
- go.opentelemetry.io/contrib/instrumentation/net/http/otelhttp `v0.68.0` → `v0.71.0`
- go.opentelemetry.io/otel `v1.43.0` → `v1.46.0` **(🟢 remediated [GO-2026-5158](https://github.com/open-telemetry/opentelemetry-go/security/advisories/GHSA-5wrp-cwcj-q835))**
- go.opentelemetry.io/otel/exporters/stdout/stdoutmetric `v1.40.0` → `v1.44.0`
- go.opentelemetry.io/otel/metric `v1.43.0` → `v1.46.0`
- go.opentelemetry.io/otel/sdk `v1.43.0` → `v1.46.0` **(🟢 remediated [GHSA-8wmf-6v46-5gfg](https://github.com/advisories/GHSA-8wmf-6v46-5gfg))**
- go.opentelemetry.io/otel/sdk/metric `v1.43.0` → `v1.46.0`
- go.opentelemetry.io/otel/trace `v1.43.0` → `v1.46.0`
- go.yaml.in/yaml/v3 `v3.0.4` → `v3.0.5`
- golang.org/x/crypto `v0.53.0` → `v0.58.0` **(🟢 remediated [GO-2026-6303](https://go.dev/issue/80213), [GO-2026-6354](https://go.dev/issue/81316), [GO-2026-6355](https://go.dev/issue/81317))**
- golang.org/x/mod `v0.37.0` → `v0.42.0` **(🟢 remediated [GO-2026-6179](https://go.dev/issue/80744), [GO-2026-6180](https://go.dev/issue/80745))**
- golang.org/x/net `v0.56.0` → `v0.61.0` **(🟢 remediated [GO-2026-6603](https://go.dev/cl/847185), [GO-2026-6610](https://go.dev/cl/835145), [GO-2026-6611](https://go.dev/cl/847186), [GO-2026-6612](https://go.dev/cl/847187), [GO-2026-6617](https://go.dev/cl/847188))**
- golang.org/x/oauth2 `v0.36.0` → `v0.37.0`
- golang.org/x/sync `v0.21.0` → `v0.24.0`
- golang.org/x/sys `v0.46.0` → `v0.49.0`
- golang.org/x/term `v0.44.0` → `v0.47.0`
- golang.org/x/text `v0.38.0` → `v0.43.0` **(🟢 remediated [GO-2026-5970](https://go.dev/issue/80142), [GO-2026-6629](https://go.dev/cl/793360))**
- golang.org/x/time `v0.15.0` → `v0.16.0`
- golang.org/x/tools `v0.46.0` → `v0.52.0`
- google.golang.org/api `v0.271.0` → `v0.299.0`
- google.golang.org/genproto `v0.0.0-8636f87` → `v0.0.0-e75dac1`
- google.golang.org/genproto/googleapis/api `v0.0.0-9d38bb4` → `v0.0.0-da73d73`
- google.golang.org/genproto/googleapis/rpc `v0.0.0-6f92a3b` → `v0.0.0-b142276`
- google.golang.org/grpc `v1.80.0` → `v1.84.0` **(🟢 remediated [GHSA-2v4p-qf9q-27wj](https://github.com/advisories/GHSA-2v4p-qf9q-27wj), [GHSA-hrxh-6v49-42gf](https://github.com/advisories/GHSA-hrxh-6v49-42gf), [GHSA-qc2q-p7wx-3px3](https://github.com/advisories/GHSA-qc2q-p7wx-3px3), [GHSA-vp52-pcj8-j9qc](https://github.com/advisories/GHSA-vp52-pcj8-j9qc))**
- google.golang.org/protobuf `v1.36.12-0.f2248ac` → `v1.36.12`
- modernc.org/cc/v4 `v4.28.4` → `v4.30.3`
- modernc.org/ccgo/v4 `v4.34.4` → `v4.37.0`
- modernc.org/gc/v3 `v3.1.3` → `v3.2.0`
- modernc.org/libc `v1.73.4` → `v1.79.0`
- modernc.org/memory `v1.11.0` → `v1.12.1`
- modernc.org/sqlite `v1.53.0` → `v1.61.0`
</details>

<details>
<summary>Added (32 packages)</summary>

- cyphar.com/go-pathrs `v0.2.5`
- github.com/VividCortex/ewma `v1.2.0`
- github.com/acarl005/stripansi `v0.0.0-5a71ef0`
- github.com/apparentlymart/go-textseg/v17 `v17.0.1`
- github.com/containerd/log/otel `v0.1.0`
- github.com/containerd/stargz-snapshotter/estargz `v0.19.0`
- github.com/containers/libtrust `v0.0.0-c1716e8`
- github.com/containers/ocicrypt `v1.3.2`
- github.com/cyberphone/json-canonicalization `v0.0.0-19d51d7`
- github.com/google/go-intervals `v0.0.2`
- github.com/mattn/go-sqlite3 `v1.14.52`
- github.com/miekg/pkcs11 `v1.1.2`
- github.com/mistifyio/go-zfs/v4 `v4.0.0`
- github.com/moby/sys/capability `v0.4.0`
- github.com/opencontainers/selinux `v1.15.1`
- github.com/proglottis/gpgme `v0.1.6`
- github.com/secure-systems-lab/go-securesystemslib `v0.11.1`
- github.com/sigstore/fulcio `v1.8.8`
- github.com/sigstore/protobuf-specs `v0.5.2`
- github.com/sigstore/sigstore `v1.10.11`
- github.com/smallstep/pkcs7 `v0.2.1`
- github.com/stefanberger/go-pkcs11uri `v0.0.0-7828495`
- github.com/tchap/go-patricia/v2 `v2.3.3`
- github.com/varlink/go `v0.4.1-0.c935be0`
- github.com/vbatts/tar-split `v0.12.3`
- github.com/vbauerster/cupwriter `v0.0.5`
- github.com/vbauerster/mpb/v8 `v8.16.2`
- github.com/youmark/pkcs8 `v0.0.0-a2c0da2`
- go.opentelemetry.io/otel/metric/x `v0.68.0`
- go.podman.io/image/v5 `v5.42.0`
- go.podman.io/storage `v1.65.0`
- howett.net/plist `v1.0.1`
</details>

<details>
<summary>Removed (6 packages)</summary>

- github.com/aws/aws-sdk-go-v2/internal/ini `v1.8.6`
- github.com/becheran/wildmatch-go `v1.0.0`
- github.com/gogo/protobuf `v1.3.2`
- github.com/klauspost/cpuid/v2 `v2.3.0`
- github.com/moby/sys/sequential `v0.6.0`
- go.opencensus.io `v0.24.0`
</details>

**[(Full Changelog)](https://github.com/anchore/grant/compare/v0.6.8...v0.7.0)**
