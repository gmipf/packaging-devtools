### Added Features

- Request ability to ignore licenseConcluded [Issue [#217](https://github.com/anchore/grant/issues/217)] [PR [#638](https://github.com/anchore/grant/pull/638) @spiffcs]

### Dependencies

11 dependency changes (10 updated, 1 added). 1 vulnerability remediated.

**🟢 Remediated (1)**

- [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69) (Medium) — go.opentelemetry.io/otel/sdk, go.opentelemetry.io/otel/trace

<details>
<summary>Updated (10 packages)</summary>

- github.com/anchore/stereoscope `v0.4.1` → `v0.4.2`
- github.com/anchore/syft `v1.57.1` → `v1.57.2`
- github.com/docker/cli `v29.9.2+incompatible` → `v29.9.3+incompatible`
- go.opentelemetry.io/otel `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/metric `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/metric/x `v0.68.0` → `v0.69.0`
- go.opentelemetry.io/otel/sdk `v1.46.0` → `v1.47.0` **(🟢 remediated [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69))**
- go.opentelemetry.io/otel/sdk/metric `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/trace `v1.46.0` → `v1.47.0` **(🟢 remediated [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69))**
- modernc.org/sqlite `v1.61.0` → `v1.61.1`
</details>

<details>
<summary>Added (1 package)</summary>

- go.opentelemetry.io/otel/log `v1.47.0`
</details>

**[(Full Changelog)](https://github.com/anchore/grant/compare/v0.7.1...v0.8.0)**
