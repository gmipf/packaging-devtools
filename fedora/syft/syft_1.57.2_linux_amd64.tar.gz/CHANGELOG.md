### Bug Fixes

- skip Linux release identification if there is nothing to parse [PR [#5482](https://github.com/anchore/syft/pull/5482) @caleballen]
- use pointer receiver for FileResolver to enable reuse [PR [#5483](https://github.com/anchore/syft/pull/5483) @caleballen]
- report dpkg packages listed in both status and status.d once [PR [#5565](https://github.com/anchore/syft/pull/5565) @spiffcs]
- find license files under .dist-info/licenses (PEP 639) [PR [#5496](https://github.com/anchore/syft/pull/5496) @ToreMerkely]
- sort uv.lock extras by name so the SBOM output is stable [PR [#5468](https://github.com/anchore/syft/pull/5468) @wleeaf]
- keep single-character names in requirements.txt [PR [#5469](https://github.com/anchore/syft/pull/5469) @protonnegativo]
- do not use libavcodec ABI versions as FFmpeg release versions [Issue [#5548](https://github.com/anchore/syft/issues/5548)] [PR [#5552](https://github.com/anchore/syft/pull/5552) @Rudra184]
- Support julia binary various versions [Issue [#5061](https://github.com/anchore/syft/issues/5061)] [PR [#5494](https://github.com/anchore/syft/pull/5494) @26wv]
- Bun classifier reports historical version text before the runtime banner [Issue [#5553](https://github.com/anchore/syft/issues/5553)] [PR [#5558](https://github.com/anchore/syft/pull/5558) @sarankumar1325]
- License normalization drops Classpath-exception-2.0 and uses AND instead of OR for Eclipse/GlassFish JARs [Issue [#5009](https://github.com/anchore/syft/issues/5009)] [PR [#5080](https://github.com/anchore/syft/pull/5080) @Eljees]

### Dependencies

10 dependency changes (9 updated, 1 added). 1 vulnerability remediated.

**🟢 Remediated (1)**

- [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69) (Medium) — go.opentelemetry.io/otel/sdk, go.opentelemetry.io/otel/trace

<details>
<summary>Updated (9 packages)</summary>

- github.com/anchore/stereoscope `v0.4.1` → `v0.4.2`
- github.com/docker/cli `v29.9.2+incompatible` → `v29.9.3+incompatible`
- go.opentelemetry.io/otel `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/metric `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/metric/x `v0.68.0` → `v0.69.0`
- go.opentelemetry.io/otel/sdk `v1.46.0` → `v1.47.0` **(🟢 remediated [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69))**
- go.opentelemetry.io/otel/sdk/metric `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/trace `v1.46.0` → `v1.47.0` **(🟢 remediated [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69))**
- modernc.org/sqlite `v1.61.0` → `v1.61.1`
</details>

<details>
<summary>Added (1 package)</summary>

- go.opentelemetry.io/otel/log `v1.47.0`
</details>

**[(Full Changelog)](https://github.com/anchore/syft/compare/v1.57.1...v1.57.2)**
