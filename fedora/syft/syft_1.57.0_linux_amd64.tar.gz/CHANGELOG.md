### Added Features

- capture GNU ELF build IDs [PR [#5426](https://github.com/anchore/syft/pull/5426) @adityasaky]
- build lower layer squashes only when a scan reads them [PR [#5492](https://github.com/anchore/syft/pull/5492) @wagoodman]

### Bug Fixes

- do not generate CPEs for msrc-kb packages [PR [#5510](https://github.com/anchore/syft/pull/5510) @juanjsebgarcia]
- Fix truncated pre-release versions in Go binaries' ldflags [PR [#5422](https://github.com/anchore/syft/pull/5422) @LemonCondor]
- generate NVD-style terraform_provider CPEs for terraform lock packages [PR [#5261](https://github.com/anchore/syft/pull/5261) @timols]

### Additional Changes

- OpenSSL-only SHA-256 fallback aborts installation [Issue [#5520](https://github.com/anchore/syft/issues/5520)] [PR [#5521](https://github.com/anchore/syft/pull/5521) @pujitha24]

### Dependencies

1 dependency change (1 updated).

<details>
<summary>Updated (1 package)</summary>

- github.com/anchore/stereoscope `v0.4.0` → `v0.4.1`
</details>

**[(Full Changelog)](https://github.com/anchore/syft/compare/v1.56.0...v1.57.0)**
