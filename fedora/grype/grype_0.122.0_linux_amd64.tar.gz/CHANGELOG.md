### Added Features

- add DHI OSV support [PR [#3613](https://github.com/anchore/grype/pull/3613) @aubm]

### Bug Fixes

- remove incorrect python lightning mapping [PR [#3922](https://github.com/anchore/grype/pull/3922) @westonsteimel]
- sort rpm caret versions above their base version [PR [#3812](https://github.com/anchore/grype/pull/3812) @spicysharkco]
- support shorthand java versions with #u# [PR [#3726](https://github.com/anchore/grype/pull/3726) @kzantow]
- parse bare CVSS v2 and prefer the newest CVSS version [PR [#3910](https://github.com/anchore/grype/pull/3910) @spiffcs]
- `--scope all-layers` does not reach Syft: packages removed in a later layer are not reported [Issue [#3897](https://github.com/anchore/grype/issues/3897)] [PR [#3904](https://github.com/anchore/grype/pull/3904) @wils0ns]

### Dependencies

14 dependency changes (13 updated, 1 added). 1 vulnerability remediated.

**🟢 Remediated (1)**

- [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69) (Medium) — go.opentelemetry.io/otel/sdk, go.opentelemetry.io/otel/trace

**Toolchains (1)**

- Go minimum version: `1.26.8` → `1.26.10`

<details>
<summary>Updated (13 packages)</summary>

- github.com/anchore/stereoscope `v0.4.1` → `v0.4.2`
- github.com/anchore/syft `v1.57.1` → `v1.57.2`
- github.com/cloudflare/circl `v1.6.3` → `v1.6.5`
- github.com/docker/cli `v29.9.2+incompatible` → `v29.9.3+incompatible`
- github.com/gocsaf/csaf/v3 `v3.5.1` → `v3.7.1`
- github.com/shopspring/decimal `v1.4.0` → `v1.6.0`
- go.opentelemetry.io/otel `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/metric `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/metric/x `v0.68.0` → `v0.69.0`
- go.opentelemetry.io/otel/sdk `v1.46.0` → `v1.47.0` **(🟢 remediated [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69))**
- go.opentelemetry.io/otel/sdk/metric `v1.46.0` → `v1.47.0`
- go.opentelemetry.io/otel/trace `v1.46.0` → `v1.47.0` **(🟢 remediated [GHSA-q7gw-24fr-5p69](https://github.com/advisories/GHSA-q7gw-24fr-5p69))**
- modernc.org/sqlite `v1.61.0` → `v1.61.1`
</details>

<details>
<summary>Added (1 package)</summary>

- go.opentelemetry.io/otel/log `v1.47.0`
</details>

**[(Full Changelog)](https://github.com/anchore/grype/compare/v0.121.3...v0.122.0)**
