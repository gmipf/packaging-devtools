### Bug Fixes

- Address gaps in grype's jvm version comparison logic [PR [#3928](https://github.com/anchore/grype/pull/3928) @westonsteimel]
- Apache Airflow CVEs matched to pkg:pypi/lightning (nvd:language:python) [Issue [#3920](https://github.com/anchore/grype/issues/3920)]

**[(Full Changelog)](https://github.com/anchore/grype/compare/v0.122.0...v0.122.1)**
