### Added Features

- OS End of life warnings should account for SupportEnd date from the distro release information [Issue [#3230](https://github.com/anchore/grype/issues/3230)] [PR [#3787](https://github.com/anchore/grype/pull/3787) @tomersein]
- Licensing: copyright owner missing, needed for Debian packaging [Issue [#3501](https://github.com/anchore/grype/issues/3501)] [PR [#3791](https://github.com/anchore/grype/pull/3791) @wagoodman]

### Bug Fixes

- fix(db-build) allow configuring sqlite cache size at db build time [PR [#3814](https://github.com/anchore/grype/pull/3814) @willmurphyscode]
- Carry AlmaLinux fix dates onto replaced RHEL matches [PR [#3773](https://github.com/anchore/grype/pull/3773) @wagoodman]
- carry fix availability through extended support fix merging [PR [#3809](https://github.com/anchore/grype/pull/3809) @bot190]
- upgrade to golang.org/x/net v0.61.0 [PR [#3802](https://github.com/anchore/grype/pull/3802) @westonsteimel]
- Swift Package Manager packages miss GitHub Swift advisories (searched by identity, not repository path) [Issue [#3795](https://github.com/anchore/grype/issues/3795)] [PR [#3713](https://github.com/anchore/grype/pull/3713) @az-catch]

### Additional Changes

- bump go-make module and action together [PR [#3793](https://github.com/anchore/grype/pull/3793) @wagoodman]

### Dependencies

50 dependency changes (47 updated, 1 added, 2 removed). 5 vulnerabilities remediated.

**🟢 Remediated (5)**

- [GO-2026-6603](https://go.dev/cl/847185) (High) — golang.org/x/net
- [GO-2026-6610](https://go.dev/cl/835145) (High) — golang.org/x/net
- [GO-2026-6611](https://go.dev/cl/847186) (High) — golang.org/x/net
- [GO-2026-6612](https://go.dev/cl/847187) (Critical) — golang.org/x/net
- [GO-2026-6617](https://go.dev/cl/847188) (High) — golang.org/x/net

<details>
<summary>Updated (47 packages)</summary>

- cloud.google.com/go/auth `v0.23.2` → `v0.23.3`
- cloud.google.com/go/compute/metadata `v0.9.0` → `v0.9.1`
- cloud.google.com/go/storage `v1.65.1` → `v1.68.0`
- github.com/GoogleCloudPlatform/opentelemetry-operations-go/detectors/gcp `v1.33.0` → `v1.34.0`
- github.com/anchore/syft `v1.54.1` → `v1.55.0`
- github.com/aws/aws-sdk-go-v2 `v1.44.0` → `v1.47.1`
- github.com/aws/aws-sdk-go-v2/config `v1.32.40` → `v1.33.6`
- github.com/aws/aws-sdk-go-v2/credentials `v1.19.39` → `v1.20.6`
- github.com/aws/aws-sdk-go-v2/feature/ec2/imds `v1.18.40` → `v1.20.1`
- github.com/aws/aws-sdk-go-v2/internal/configsources `v1.4.40` → `v1.5.4`
- github.com/aws/aws-sdk-go-v2/internal/endpoints/v2 `v2.7.40` → `v2.8.4`
- github.com/aws/aws-sdk-go-v2/internal/v4a `v1.4.41` → `v1.5.4`
- github.com/aws/aws-sdk-go-v2/service/internal/checksum `v1.10.0` → `v1.11.5`
- github.com/aws/aws-sdk-go-v2/service/internal/presigned-url `v1.13.40` → `v1.14.4`
- github.com/aws/aws-sdk-go-v2/service/internal/s3shared `v1.19.41` → `v1.20.4`
- github.com/aws/aws-sdk-go-v2/service/s3 `v1.108.0` → `v1.114.0`
- github.com/aws/aws-sdk-go-v2/service/signin `v1.6.0` → `v1.10.1`
- github.com/aws/aws-sdk-go-v2/service/sso `v1.34.0` → `v1.38.1`
- github.com/aws/aws-sdk-go-v2/service/ssooidc `v1.39.0` → `v1.43.1`
- github.com/aws/aws-sdk-go-v2/service/sts `v1.46.0` → `v1.51.1`
- github.com/github/go-spdx/v2 `v2.7.0` → `v2.7.1`
- github.com/go-git/go-billy/v5 `v5.9.1` → `v5.9.2`
- github.com/go-git/go-git/v5 `v5.19.2` → `v5.19.3`
- github.com/google/s2a-go `v0.1.9` → `v0.1.10`
- github.com/googleapis/enterprise-certificate-proxy `v0.3.20` → `v0.3.22`
- github.com/googleapis/gax-go/v2 `v2.24.0` → `v2.24.1`
- github.com/gookit/color `v1.6.1` → `v1.6.2`
- github.com/gpustack/gguf-parser-go `v0.26.3` → `v0.26.4`
- github.com/hashicorp/go-getter `v1.8.9` → `v1.8.10`
- github.com/pb33f/ordered-map/v2 `v2.3.1` → `v2.3.2`
- github.com/pjbgf/sha1cd `v0.6.0` → `v0.7.0`
- github.com/spiffe/go-spiffe/v2 `v2.7.0` → `v2.8.1`
- golang.org/x/crypto `v0.57.0` → `v0.58.0`
- golang.org/x/net `v0.59.0` → `v0.61.0` **(🟢 remediated [GO-2026-6603](https://go.dev/cl/847185), [GO-2026-6610](https://go.dev/cl/835145), [GO-2026-6611](https://go.dev/cl/847186), [GO-2026-6612](https://go.dev/cl/847187), [GO-2026-6617](https://go.dev/cl/847188))**
- golang.org/x/oauth2 `v0.36.0` → `v0.37.0`
- golang.org/x/sync `v0.23.0` → `v0.24.0`
- golang.org/x/sys `v0.48.0` → `v0.49.0`
- golang.org/x/term `v0.46.0` → `v0.47.0`
- golang.org/x/text `v0.42.0` → `v0.43.0`
- golang.org/x/tools `v0.50.0` → `v0.51.0`
- google.golang.org/api `v0.294.0` → `v0.299.0`
- google.golang.org/genproto/googleapis/rpc `v0.0.0-da73d73` → `v0.0.0-b142276`
- google.golang.org/grpc `v1.83.2` → `v1.84.0`
- modernc.org/cc/v4 `v4.29.2` → `v4.29.7`
- modernc.org/ccgo/v4 `v4.35.0` → `v4.36.1`
- modernc.org/libc `v1.75.7` → `v1.77.1`
- modernc.org/sqlite `v1.59.0` → `v1.60.1`
</details>

<details>
<summary>Added (1 package)</summary>

- github.com/pb33f/go-yaml `v0.1.0`
</details>

<details>
<summary>Removed (2 packages)</summary>

- github.com/klauspost/cpuid/v2 `v2.3.0`
- go.yaml.in/yaml/v4 `v4.0.0-rc.2`
</details>

**[(Full Changelog)](https://github.com/anchore/grype/compare/v0.120.1...v0.121.0)**
