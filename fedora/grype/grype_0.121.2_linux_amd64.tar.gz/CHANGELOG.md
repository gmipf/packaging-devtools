### Bug Fixes

- deterministic ordering of db search match results [PR [#3883](https://github.com/anchore/grype/pull/3883) @wagoodman]

### Dependencies

2 dependency changes (2 updated).

<details>
<summary>Updated (2 packages)</summary>

- github.com/anchore/stereoscope `v0.4.0` → `v0.4.1`
- github.com/anchore/syft `v1.56.0` → `v1.57.0`
</details>

**[(Full Changelog)](https://github.com/anchore/grype/compare/v0.121.1...v0.121.2)**
