### Bug Fixes

- extract the quality gate debug artifact outside the checkout [PR [#3875](https://github.com/anchore/grype/pull/3875) @wagoodman]
- incorrect constraint for versionless purls in openvex [PR [#3874](https://github.com/anchore/grype/pull/3874) @kzantow]
- report additional version-range records for a package [PR [#3782](https://github.com/anchore/grype/pull/3782) @jspilman]
- report a package's vulnerability as added or removed only when its affected record set changes [PR [#3784](https://github.com/anchore/grype/pull/3784) @jspilman]
- report the lowest overlapping AlmaLinux fix [PR [#3783](https://github.com/anchore/grype/pull/3783) @jspilman]
- report fix date and kind changes under the package [PR [#3781](https://github.com/anchore/grype/pull/3781) @jspilman]
- label db diff databases in the order they were provided [PR [#3816](https://github.com/anchore/grype/pull/3816) @bot190]
- time out stalled db diff downloads [PR [#3858](https://github.com/anchore/grype/pull/3858) @wagoodman]
- only remove db diff directories that grype created [PR [#3828](https://github.com/anchore/grype/pull/3828) @wagoodman]
- make db diff --packages and --vulns include only what was requested [PR [#3815](https://github.com/anchore/grype/pull/3815) @bot190]

### Performance

- index ignore rules by vulnerability ID [PR [#3817](https://github.com/anchore/grype/pull/3817) @juanjsebgarcia]
- speed up db diff and reduce its memory and temp disk use [PR [#3813](https://github.com/anchore/grype/pull/3813) @bot190]

### Additional Changes

- grype 0.119.0 allocates without bound on a CycloneDX machine-learning-model component with no purl and no CPE [Issue [#3767](https://github.com/anchore/grype/issues/3767)]
- add a directory for grype-specific match labels [PR [#3849](https://github.com/anchore/grype/pull/3849) @wagoodman]
- let go-make own the go version and move images to debian13 [PR [#3840](https://github.com/anchore/grype/pull/3840) @wagoodman]

### Dependencies

41 dependency changes (39 updated, 1 added, 1 removed). 1 vulnerability remediated.

**🟢 Remediated (1)**

- [GHSA-mgcc-cww5-fp2q](https://github.com/advisories/GHSA-mgcc-cww5-fp2q) (High) — github.com/go-jose/go-jose/v4

<details>
<summary>Updated (39 packages)</summary>

- github.com/Microsoft/go-winio `v0.6.3-0.ad3df93` → `v0.6.3-0.f19d971`
- github.com/ProtonMail/go-crypto `v1.4.1` → `v1.5.2`
- github.com/anchore/clio `v0.1.1` → `v0.1.2`
- github.com/anchore/stereoscope `v0.3.4` → `v0.4.0`
- github.com/anchore/syft `v1.55.0` → `v1.56.0`
- github.com/bmatcuk/doublestar/v4 `v4.10.2` → `v4.10.3`
- github.com/containerd/containerd/v2 `v2.4.1` → `v2.4.2`
- github.com/containerd/stargz-snapshotter/estargz `v0.18.2` → `v0.19.0`
- github.com/deitch/magic `v0.0.0-c67ab88` → `v1.0.0`
- github.com/docker/cli `v29.8.2+incompatible` → `v29.9.2+incompatible`
- github.com/docker/docker-credential-helpers `v0.9.8` → `v0.9.10`
- github.com/docker/go-connections `v0.8.1` → `v0.8.2`
- github.com/gabriel-vasile/mimetype `v1.4.15` → `v1.4.16`
- github.com/github/go-spdx/v2 `v2.7.1` → `v2.8.0`
- github.com/gkampitakis/go-snaps `v0.5.23` → `v0.5.24`
- github.com/go-jose/go-jose/v4 `v4.1.5` → `v4.1.6` **(🟢 remediated [GHSA-mgcc-cww5-fp2q](https://github.com/advisories/GHSA-mgcc-cww5-fp2q))**
- github.com/go-test/deep `v1.1.1` → `v1.1.2`
- github.com/google/pprof `v0.0.0-ef3492d` → `v0.0.0-1facf8f`
- github.com/gookit/color `v1.6.2` → `v1.6.3`
- github.com/gpustack/gguf-parser-go `v0.26.4` → `v0.27.0`
- github.com/klauspost/compress `v1.20.1` → `v1.20.3`
- github.com/klauspost/pgzip `v1.2.6` → `v1.2.7`
- github.com/mattn/go-runewidth `v0.0.27` → `v0.0.31`
- github.com/mattn/go-sqlite3 `v1.14.48` → `v1.14.52`
- github.com/moby/moby/api `v1.56.0` → `v1.56.1`
- github.com/moby/moby/client `v0.6.0` → `v0.6.2`
- github.com/ncruces/go-strftime `v1.0.0` → `v1.1.0`
- github.com/sigstore/fulcio `v1.8.7` → `v1.8.8`
- github.com/vbauerster/cupwriter `v0.0.4` → `v0.0.5`
- github.com/vbauerster/mpb/v8 `v8.14.0` → `v8.16.2`
- go.podman.io/image/v5 `v5.41.2` → `v5.42.0`
- go.podman.io/storage `v1.64.1` → `v1.65.0`
- golang.org/x/mod `v0.41.0` → `v0.42.0`
- golang.org/x/tools `v0.51.0` → `v0.52.0`
- modernc.org/cc/v4 `v4.29.7` → `v4.30.3`
- modernc.org/ccgo/v4 `v4.36.1` → `v4.37.0`
- modernc.org/gc/v3 `v3.1.5` → `v3.2.0`
- modernc.org/libc `v1.77.1` → `v1.79.0`
- modernc.org/sqlite `v1.60.1` → `v1.61.0`
</details>

<details>
<summary>Added (1 package)</summary>

- github.com/varlink/go `v0.4.1-0.c935be0`
</details>

<details>
<summary>Removed (1 package)</summary>

- github.com/becheran/wildmatch-go `v1.0.0`
</details>

**[(Full Changelog)](https://github.com/anchore/grype/compare/v0.121.0...v0.121.1)**
